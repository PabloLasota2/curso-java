import java.util.Scanner;

public class Programa{
 public static void main(String args[]){

  Scanner entrada = new Scanner(System.in);
  String nombreEmpleado = "";
  int claveArea = 0, antiguedad = 0, diasVacas = 0;

  System.out.println("Bienvenido al Programa de Coca-Cola\n\n");
  
  System.out.println("Ingrese el nombre del empleado:");
  nombreEmpleado = entrada.nextLine();

  System.out.println("Ingrese la clave de area del empleado\n1-Atencion al Cliente\n2-Logistica\n3-Gerencia");
  claveArea = entrada.nextInt();

  System.out.println("¿Cuantos años lleva trabajando?");
  antiguedad= entrada.nextInt();
  
  
   if(claveArea == 1){
    if(antiguedad <= 1){
     System.out.println("A "+nombreEmpleado+" le corresponden 6 dias");
    }
    if(antiguedad > 1 && antiguedad <= 6){
     System.out.println("A "+nombreEmpleado+" le corresponden 14 dias");
    }
    else if(antiguedad > 6){
     System.out.println("A "+nombreEmpleado+" le corresponden 20 dias");
    }
   }
   if(claveArea == 2){
    if(antiguedad <= 1){
     System.out.println("A "+nombreEmpleado+" le corresponden 7 dias");
    }
    if(antiguedad > 1 && antiguedad <= 6){
     System.out.println("A "+nombreEmpleado+" le corresponden 15 dias");
    }
    else if(antiguedad > 6){
     System.out.println("A "+nombreEmpleado+" le corresponden 22 dias");
    }
   }
    if(claveArea == 3){
     if(antiguedad <= 1){
     System.out.println("A "+nombreEmpleado+" le corresponden 10 dias");
    }
     if(antiguedad > 1 && antiguedad <= 6){
     System.out.println("A "+nombreEmpleado+" le corresponden 20 dias");
    }
     else if(antiguedad > 6){
     System.out.println("A "+nombreEmpleado+" le corresponden 30 dias");
   }
   else{
    System.out.println("No existe esa area en la compañia.");
   }
  }
 }
}