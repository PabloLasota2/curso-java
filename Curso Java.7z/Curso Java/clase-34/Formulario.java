import javax.swing.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ItemListener{
  private JComboBox caja;

  public Formulario(){
    setLayout(null);
    
    caja = new JComboBox();
    caja.setBounds(5,5,70,20);
    add(caja);

    caja.addItem("Azul");
    caja.addItem("Amarillo");
    caja.addItem("Magenta");
    caja.addItem("Verde");
    caja.addItem("Negro");
    caja.addItemListener(this);
  }
  public void itemStateChanged(ItemEvent e){
    if(e.getSource() == caja){
      String estado = "";
      estado = caja.getSelectedItem().toString();
      setTitle(estado);
    }
  }

  public static void main(String args[]){
    Formulario form  = new Formulario();

    form.setBounds(0,0,50,50);
    form.setResizable(false);
    form.setVisible(true);
    form.setLocationRelativeTo(null);
  }


}