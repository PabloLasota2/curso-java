import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ActionListener{
  private JLabel label_1, label_2, label_3;
  private JComboBox box_1, box_2, box_3;
  private JButton boton;

  public Formulario(){
    setLayout(null);
    
    label_1 = new JLabel("Rojo:");
    label_1.setBounds(10,10,70,20);
    add(label_1);

    label_2 = new JLabel("Verde:");
    label_2.setBounds(10,40,70,20);
    add(label_2);

    label_3 = new JLabel("Azul:");
    label_3.setBounds(10,70,70,20);
    add(label_3);

    box_1 = new JComboBox();
    box_1.setBounds(110,10,70,20);
    for(int i = 0; i < 255; i++){
      box_1.addItem(String.valueOf(i)); 
    }
    add(box_1);

    box_2 = new JComboBox();
    box_2.setBounds(110,40,70,20);
    for(int i = 0; i < 255; i++){
      box_2.addItem(String.valueOf(i)); 
    }
    add(box_2);

    box_3 = new JComboBox();
    box_3.setBounds(110,70,70,20);
    for(int i = 0; i < 255; i++){
      box_3.addItem(String.valueOf(i)); 
    }
    add(box_3);

    boton = new JButton("Fijar color.");
    boton.setBounds(10,100,70,20);
    add(boton);
    boton.addActionListener(this);
  }
  public void actionPerformed(ActionEvent e){
    if(e.getSource() == boton){
      String cad1,cad2,cad3;
      int rojo,verde,azul;
      cad1 = box_1.getSelectedItem().toString();
      cad2 = box_2.getSelectedItem().toString();
      cad3 = box_3.getSelectedItem().toString();

      rojo = Integer.parseInt(cad1);
      verde = Integer.parseInt(cad2);
      azul = Integer.parseInt(cad3);

      Color color1 = new Color(rojo,verde,azul);
      boton.setBackground(color1);
    }
  }
  public static void main(String args[]){
    Formulario form = new Formulario();

    form.setBounds(0,0,300,300);
    form.setVisible(true);
    form.setResizable(false);
    form.setLocationRelativeTo(null);
  }
}