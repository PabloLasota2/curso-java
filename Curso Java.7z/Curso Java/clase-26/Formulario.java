import javax.swing.*;

public class Formulario extends JFrame{
  private JLabel label01;
  private JLabel label02;
  
  public Formulario(){
   setLayout(null);
   label01 = new JLabel("Esto es una interfaz grafica");
   label01.setBounds(10,20,300,30);
   add(label01);
   label02 = new JLabel("Version 1.0");
   label02.setBounds(10,40,100,30);
   add(label02);
 }
  public static void main(String args[]){
   Formulario form01 = new Formulario();
   form01.setBounds(0,0,500,200);
   form01.setResizable(false);
   form01.setVisible(true);
   form01.setLocationRelativeTo(null);
 }
}