import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ChangeListener, ActionListener{
  private JCheckBox box;
  private JLabel label;
  private JButton botonAceptar;
  
  public Formulario(){
    setLayout(null);

    label = new JLabel("Termino y condiciones....");
    label.setBounds(10,10,150,20);
    add(label);

    box = new JCheckBox("Acepto");
    box.setBounds(10,40,150,20);
    box.addChangeListener(this);
    add(box);

    botonAceptar = new JButton("Aceptar");
    botonAceptar.setBounds(10,100,150,30);
    botonAceptar.addActionListener(this);
    add(botonAceptar);
    botonAceptar.setEnabled(false);
  }

  public void stateChanged(ChangeEvent e){
    if(box.isSelected()){
      botonAceptar.setEnabled(true);
    }
    else{
      botonAceptar.setEnabled(false);
    }
  }
  
  public void actionPerformed(ActionEvent e){
    if(e.getSource() == botonAceptar){
      System.exit(0);
    }
  }
  
  public static void main(String args[]){
    Formulario form = new Formulario();
    form.setBounds(0,0,300,200);
    form.setVisible(true);
    form.setResizable(false);
    form.setLocationRelativeTo(null);
  }
}