import javax.swing.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ActionListener{
  JButton boton01;
  public Formulario(){
   setLayout(null);
   boton01 = new JButton("Cerrar");
   boton01.setBounds(300,250,100,30);
   add(boton01);
   boton01.addActionListener(this);
  }
  public void actionPerformed(ActionEvent e){
   if(e.getSource() == boton01){
    System.exit(0);
   }
  }
  public static void main(String args[]){
   Formulario form = new Formulario();
   form.setBounds(0,0,450,350);
   form.setVisible(true);
   form.setLocationRelativeTo(null);
   form.setResizable(false);
 }
}