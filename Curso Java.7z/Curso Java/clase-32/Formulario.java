import javax.swing.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ActionListener{
  private JTextField text_field;
  private JScrollPane scroll_text;
  private JTextArea text_area;
  private JButton boton_agregar;
  
  String aux = "";
  
  public Formulario(){
    setLayout(null);
    
    text_field = new JTextField();
    text_field.setBounds(10,10,100,30);
    add(text_field);

    text_area = new JTextArea();
    scroll_text = new JScrollPane(text_area);
    scroll_text.setBounds(10,40,200,400);
    add(scroll_text);

    boton_agregar = new JButton("Agregar");
    boton_agregar.setBounds(130,10,50,30);
    add(boton_agregar);
    boton_agregar.addActionListener(this);
  }
  public void actionPerformed(ActionEvent e){
    if(e.getSource() == boton_agregar){
      aux += text_field.getText() + "\n";
      text_area.setText(aux);
      text_field.setText("");    
    }
  }
  public static void main(String args[]){
    Formulario form = new Formulario();
    form.setBounds(0,0,250,500);
    form.setVisible(true);
    form.setResizable(false);
    form.setLocationRelativeTo(null);
  }

}