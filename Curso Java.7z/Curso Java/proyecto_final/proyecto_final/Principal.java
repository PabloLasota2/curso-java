import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;

public class Principal extends JFrame implements ItemListener, ActionListener{
	private JLabel label_logo,label_bienvenido,label_datos,label_nombre,label_apellidoM,label_apellidoP,label_depto,label_antig,label_result,label_validacion;
	private JMenuBar barra;
	private JMenu menu_opciones,menu_calculo,menu_acerca,menu_CFondo;
	private JMenuItem item_CRojo,item_CNegro, item_CVioleta, item_nuevo,item_salir, item_calcular, item_creador;
	private JComboBox comboBox_depto, comboBox_antig;
	private JTextField texto_nombre; texto_apellidoM, texto_apellidoP;
	private JTextArea text_area;
	private JScrollPane text_scroll;

	public Principal(){
		setLayout(null);
		setTitle("Pantalla principal");
		getContentPane().setBackgorund(new Color(255,0,0));
		setIconImage(new ImageIcon(getClass().getResource("images/icon.png")).getImage());

		barra = new JMenuBar();
		setJMenuBar(barra);

		menu_opciones = new JMenu("Opciones");
		menu_opciones.setFont(new Font("Andale Mono",1,14));
		menu_opciones.setForeground(new Color(255,0,0));
		barra.add(menu_opciones);

		menu_calculo = new JMenu("Calcular");
		menu_calculo.setFont(new Font("Andale Mono",1,14));
		menu_calculo.setForeground(new Color(255,0,0));
		barra.add(menu_calculo);

		menu_acerca = new JMenu("Acerca de...");
		menu_acerca.setFont(new Font("Andale Mono",1,14));
		menu_acerca.setForeground(new Color(255,0,0));
		barra.add(menu_acerca);

		menu_CFondo = new JMenu("Fondo");
		menu_CFondo.setFont(new Font("Andale Mono",1,14));
		menu_CFondo.setForeground(new Color(255,0,0));
		menu_opciones.add(menu_CFondo);

		item_CVioleta = new JMenuItem("Violeta");
		item_CVioleta.setFont(new Font("Andale Mono",0,14));
		item_CVioleta.setForeground(new Color(255,0,0));
		item_CVioleta.addActionListener(this);
		menu_CFondo.add(item_CVioleta);

		item_CNegro = new JMenuItem("Negro");
		item_CNegro.setFont(new Font("Andale Mono",0,14));
		item_CNegro.setForeground(new Color(255,0,0));
		item_CNegro.addActionListener(this);
		menu_CFondo.add(item_CNegro);

		item_CRojo = new JMenuItem("Rojo");
		item_CRojo.setFont(new Font("Andale Mono",0,14));
		item_CRojo.setForeground(new Color(255,0,0));
		item_CRojo.addActionListener(this);
		menu_CFondo.add(item_CRojo);

		item_nuevo = new JMenuItem("Nuevo");
		item_nuevo.setFont(new Font("Andale Mono",0,14));
		item_nuevo.setForeground(new Color(255,0,0));
		item_nuevo.addActionListener(this);
		menu_opciones.add(item_nuevo);

		item_salir = new JMenuItem("Salir");
		item_salir.setFont(new Font("Andale Mono",0,14));
		item_salir.setForeground(new Color(255,0,0));
		item_salir.addActionListener(this);
		menu_opciones.add(item_salir);

		item_calcular = new JMenuItem("Vacaciones");
		item_calcular.setFont(new Font("Andale Mono",0,14));
		item_calcular.setForeground(new Color(255,0,0));
		item_calcular.addActionListener(this);
		menu_calculo.add(item_calcular);

		item_creador = new JMenuItem("Creador");
		item_creador.setFont(new Font("Andale Mono",0,14));
		item_creador.setForeground(new Color(255,0,0));
		item_creador.addActionListener(this);
		menu_acerca.add(item_creador);

		ImageIcon logotipo = new ImageIcon("images/coca-cola-blanco.png");
		label_logo = new JLabel(logotipo);
		label_logo.setBounds(5,5,250,100);
		add(label_logo);

		label_bienvenido = new JLabel("Bienvenido");
		label_bienvenido.setBounds(280,20,300,50);
		label_bienvenido.setFont(new Font("Andale Mono",1,32));
		label_bienvenido.setForeground(new Color(255,255,255));
		add(label_bienvenido);

		label_datos = new JLabel("Datos del trabajador para el calculo");
		label_datos.setBounds(45,140,900,25);
		label_datos.setFont(new Font("Andale Mono",0,24));
		label_datos.setForeground(new Color(255,255,255));
		add(label_datos);

		//NOMBRE
		label_nombre = new JLabel("Nombre:");
		label_nombre.setBounds(25,188,188,25);
		label_nombre.setFont(new Font("Andale Mono",1,12));
		label_nombre.setForeground(new Color(255,255,255));
		add(label_nombre);

		texto_nombre = new JTextField();
		texto_nombre.setBounds(25,213,150,25);
		texto_nombre.setBackgorund(new Color(224,224,244));
		texto_nombre.setFont(new Font("Andale Mono",0,14));
		texto_nombre.setForeground(new Color(255,0,0));
		add(texto_nombre);

		//APELLIDO MATERNO
		label_apellidoM = new JLabel("Apellido materno:");
		label_apellidoM.setBounds(25,248,188,25);
		label_apellidoM.setFont(new Font("Andale Mono",1,12));
		label_apellidoM.setForeground(new Color(255,255,255));
		add(label_apellidoM);

		texto_apellidoM = new JTextField();
		texto_apellidoM.setBounds(25,273,150,25);
		texto_apellidoM.setBackgorund(new Color(224,244,244));
		texto_apellidoM.setFont(new Font("Andale Mono",0,14));
		texto_apellidoM.setForeground(new Color(255,0,0));
		add(texto_apellidoM);

		//APELLIDO PATERNO
		label_apellidoP = new JLabel("Apellido paterno:");
		label_apellidoP.setBounds(25,308,108,25);
		label_apellidoP.setFont(new Font("Andale Mono",1,12));
		label_apellidoP.setForeground(new Color(255,255,255));
		add(label_apellidoP);

		texto_apellidoP = new JTextField();
		texto_apellidoP.setBounds(25,334,150,25);
		texto_apellidoP.setBackgorund(new Color(224,244,244));
		texto_apellidoP.setFont(new Font("Andale Mono",0,14));
		texto_apellidoP.setForeground(new Color(255,0,0));
		add(texto_apellidoP);

		//SELECCION DE DEPARTAMENTO
		label_depto = new JLabel("Seleccione el departamento:");
		label_depto.setBounds(220,188,180,25);
		label_depto.setFont(new Font("Andale Mono",1,12));
		label_depto.setForeground(new Color(255,255,255));
		add(label_depto);

		comboBox_depto = new JComboBox();
		comboBox_depto.setBounds(220,213,220,25);
		comboBox_depto.setBackgorund(new Color(224,224,224));
		comboBox_depto.setFont(new Font("Andale Mono",0,14));
		comboBox_depto.setForeground(new Color(255,0,0));
		add(comboBox_depto);
		comboBox_depto.addItem("");
		comboBox_depto.addItem("Atencion al cliente");
		comboBox_depto.addItem("Logistica");
		comboBox_depto.addItem("Gerencia");

		//SELECCION DE ANTIGUEDAD
		label_antig = new JLabel("Seleccione la antigüedad:");
		label_antig.setBounds(220,248,180,25);
		label_antig.setFont(new Font("Andale Mono",1,12));
		label_antig.setForeground(new Color(255,255,255));
		add(label_antig);

		comboBox_antig = new JComboBox();
		comboBox_antig.setBounds(220,273,220,25);
		comboBox_antig.setBackgorund(new Color(224,224,224));
		comboBox_antig.setFont(new Font("Andale Mono",0,14));
		comboBox_antig.setForeground(new Color(255,0,0));
		add(comboBox_antig);
		comboBox_antig.addItem("");
		comboBox_antig.addItem("1(un) año de servicio");
		comboBox_antig.addItem("2(dos) a 6(seis) años de servicio");
		comboBox_antig.addItem("7(siete) o mas años de servicio")

		//RESULTADO DE LA OPERACION DE VACACIONES
		label_result = new JLabel("Resultado del calculo:");
		label_result.setBounds(220,307,180,25);
		label_result.setFont(new Font("Andale Mono",1,12));
		label_result.setForeground(new Color(255,255,255));
		add(label_result);

		//TEXT AREA DE RESULTADO
		text_area = new JTextArea();
		text_area.setEditable(false);
		text_area.setFont(new Font("Andale Mono",0,14));
		text_area.setForeground(new Color(255,0,0));
		text_area.setBackgorund(new Color(224,224,224));
		text_area.setText("\n Aqui aparece el resultado del calculo de vacaicones");
		text_scroll = new JScrollPane(text_area);
		text_scroll.setBounds(220,330,385,90);
		add(text_scroll);


		label_validacion = new JLabel("©2020 The Coca-Cola Company | Todos los derechos reservados");
		label_validacion.setBounds(135,445,500,30);
		label_validacion.setFont(new Font("Andale Mono",1,12));
		label_validacion.setForeground(new Color(255,255,255));
		add(label_validacion);
	}
	public void actionPerfomed(ActionEvent e){

	}
	public void itemStateChanged(ItemEvent e){
		
	}
}