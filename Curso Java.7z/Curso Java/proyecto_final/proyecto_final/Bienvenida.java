import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Bienvenida extends JFrame implements ActionListener{
	private JLabel label_1,label_2,label_3,label_4;
	private JButton boton_ingresar;
	private JTextField text_field;


	public Bienvenida(){
		setLayout(null);
		setTitle("Bienvenida");
		getContentPane().setBackground(new Color(255,0,0));
		setIconImage(new ImageIcon(getClass().getResource("images/icon.png")).getImage());

		ImageIcon imagen_logo = new ImageIcon("images/logo-coca.png");
		label_1 = new JLabel(imagen_logo);
		label_1.setBounds(25,15,300,150);
		add(label_1);

		label_2 = new JLabel("Sistema de Control Vacacional");
		label_2.setBounds(35,135,300,30);
		label_2.setFont(new Font("Andale Mono", 3, 18));
		label_2.setForeground(new Color(255,255,255));
		add(label_2);

		label_3 = new JLabel("Ingrese su nombre:");
		label_3.setBounds(45,212,200,30);
		label_3.setFont(new Font("Andale Mono",0,12));
		label_3.setForeground(new Color(255,255,255));
		add(label_3);

		label_4 = new JLabel("©2020 The Coca-Cola Company.");
		label_4.setBounds(85,375,300,30);
		label_4.setFont(new Font("Andale Mono", 1, 12));
		label_4.setForeground(new Color(255,255,255));
		add(label_4);

		text_field = new JTextField();
		text_field.setBounds(45,240,255,35);
		text_field.setBackground(new Color(224,224,224));
		text_field.setFont(new Font("Andale Mono", 1, 15));
		text_field.setForeground(new Color(255,0,0));
		add(text_field);

		boton_ingresar = new JButton("Ingresar");
		boton_ingresar.setBounds(125,280,100,30);
		boton_ingresar.setBackground(new Color(255,255,255));
		boton_ingresar.setFont(new Font("Andale Mono",1,15));
		boton_ingresar.setForeground(new Color(255,0,0));
		boton_ingresar.addActionListener(this);
		add(boton_ingresar);
	}

	public void actionPerformed(ActionEvent e){
		if(e.getSource() == boton_ingresar){
			
		}
	}

	public static void main(String args[]){
		Bienvenida form = new Bienvenida();
		form.setBounds(0,0,350,550);
		form.setVisible(true);
		form.setResizable(false);
		form.setLocationRelativeTo(null);
	}
}