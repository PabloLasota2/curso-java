import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;

public class Licencia extends JFrame implements ActionListener, ChangeListener{
	private JLabel label_1, label_2;
	private JCheckBox box;
	private JButton boton_continuar, boton_no;
	private JTextArea text_area;
	private JScrollPane scroll;

	public Licencia(){
		setLayout(null);
		setTitle("Licencia de uso");
		setIconImage(new ImageIcon(getClass().getResource("images/icon.png")).getImage());

		label_1 = new JLabel("\n\n          TERMINOS Y CONDICIONES DEL USO");
		label_1.setBounds(215,5,250,20);
		label_1.setFont(new Font("Andale Mono",1,15));
		add(label_1);

		text_area = new JTextArea();
		text_area.setEditable(false);
		text_area.setFont(new Font("Andale Mono",0,9));
		text_area.setText("Terminos y condiciones");
		scroll = new JScrollPane(text_area);
		scroll.setBounds(10,40,575,200);
		add(scroll);

		box = new JCheckBox("Yo acepto");
		box.setBounds(10,250,300,30);
		box.addChangeListener(this);
		add(box);

		boton_continuar = new JButton("Continuar");
		boton_continuar.setBounds(10,290,100,30);
		boton_continuar.addActionListener(this);
		boton_continuar.setEnabled(false);
		add(boton_continuar);

		boton_no = new JButton("No");
		boton_no.setBounds(120,290,100,30);
		boton_no.addActionListener(this);
		boton_no.setEnabled(true);
		add(boton_no);		

		ImageIcon imagen = new ImageIcon("images/coca-cola.png");
		label_2 = new JLabel(imagen);
		label_2.setBounds(315,135,300,300);
		add(label_2);
	}

	public void stateChanged(ChangeEvent e){
		if(box.isSelected()){
			boton_continuar.setEnabled(true);
			boton_no.setEnabled(false);
		}
		else{
			boton_continuar.setEnabled(false);
			boton_no.setEnabled(true);
		}
	}

	public void actionPerformed(ActionEvent e){

	}

	public static void main(String args[]){
		Licencia terms = new Licencia();
		terms.setBounds(0,0,600,360);
		terms.setVisible(true);
		terms.setResizable(false);
		terms.setLocationRelativeTo(null);
	}

}

