import javax.swing.*;

public class Formulario extends JFrame{
  private JScrollPane panel1;
  private JTextArea text_area1;

  public Formulario(){
    setLayout(null);
    text_area1 = new JTextArea(); 
    panel1 = new JScrollPane(text_area1);
    panel1.setBounds(10,10,200,300);
    add(panel1);
  }
  public static void main(String args[]){
    Formulario form = new Formulario();
    form.setBounds(0,0,310,410);
    form.setVisible(true);
    form.setResizable(false);
    form.setLocationRelativeTo(null);
  }
}