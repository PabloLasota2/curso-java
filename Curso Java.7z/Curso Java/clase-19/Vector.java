import java.util.Scanner;

public class Vector{
  public static void main(String args[]){

  Scanner entrada = new Scanner(System.in);
  int numero[] = new int[5];

  for(int i = 0; i < numeros.length; i++){
    for(int j = 0; j < 50; j++){
      System.out.println();
    }
    System.out.println("Ingrese un valor: ");
    numero[i] = entrada.nextInt();
  }

  for(int i = 0; i < numeros.length; i++){
    System.out.println(numero[i]);
  }
 }
}