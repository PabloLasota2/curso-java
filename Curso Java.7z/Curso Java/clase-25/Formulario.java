import javax.swing.*;

public class Formulario extends JFrame{
  public Formulario(){
   setLayout(null);
 }

  public static void main(String args[]){

   Formulario form = new Formulario();
   form.setBounds(0,0,400,550);
   form.setVisible(true);
   form.setLocationRelativeTo(null);
   form.setResizable(false);

 }
}