import java.util.Scanner;

public class Nombres{
  public static void main(String args[]){
   
  String nombreUno = "", nombreDos = "";
  Scanner in = new Scanner(System.in);
  
  System.out.print("Escriba el primer nombre:");
  nombreUno = in.nextLine();
  System.out.print("Escriba el segundo nombre:");
  nombreDos = in.nextLine();

  if(nombreUno.equals(nombreDos)){
   System.out.println("Los nombres son iguales!");  
  }
  else{
   System.out.println("Los nombres son diferentes!");
  }
 }
}