import java.util.Scanner;

public class LogIn{
  public static void main(String args[]){
   
  String userCorrecto= "PabloL", passwordCorrecto = "Pepe123";
  String user = "", password = "";
  Scanner in = new Scanner(System.in);
  
  System.out.print("Escriba su nombre de usuario:");
  user = in.nextLine();
  System.out.print("Escriba su contraseña:");
  password = in.nextLine();

  if(user.equalsIgnoreCase(userCorrecto) && password.equals(passwordCorrecto)){
   System.out.println("Entrada correcta!");
  }
  else{
   System.out.println("Alguno de los datos esta mal!");
  }
 }
}