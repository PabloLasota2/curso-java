import java.util.Scanner;

public class Matriz{
  public static void main(String args[]){
   
   int relleno = 1, filas = 0, columnas = 0;
   Scanner entrada = new Scanner(System.in);
   
   System.out.print("Cuantas filas queres que tenga tu matriz?: ");
   filas = entrada.nextInt();
   System.out.print("Cuantas columnas queres que tenga tu matriz?: ");
   columnas = entrada.nextInt();

   int matriz[][] = new int [filas][columnas];

   for(int i = 0; i < columnas; i++){
    for(int j = 0; j < filas; j++){
     matriz[j][i] = relleno;
     relleno++;
     System.out.print("["+matriz[j][i]+"]");
   }
    System.out.println("");
  }
 }
}