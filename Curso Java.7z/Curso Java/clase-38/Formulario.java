import javax.swing.*;
import javax.swing.event.*;

public class Formulario extends JFrame implements ChangeListener{
  private JCheckBox box1, box2;
  
  public Formulario(){
    setLayout(null);

    box1 = new JCheckBox("Ingles");
    box1.setBounds(10,10,150,20);
    box1.addChangeListener(this);
    add(box1);
    
    box2 = new JCheckBox("Ingles");
    box2.setBounds(10,50,150,20);
    box2.addChangeListener(this);
    add(box2);
  }

  public void stateChanged(ChangeEvent e){
    String cad = "";
    
    if(box1.isSelected()){
       cad = cad + "Ingles-";
    }
    if(box2.isSelected()){
      cad = cad + "Aleman-";
    }
    setTitle(cad);
  }
  
  public static void main(String args[]){
    Formulario form = new Formulario();
    form.setBounds(0,0,300,200);
    form.setVisible(true);
    form.setResizable(false);
    form.setLocationRelativeTo(null);
  }
}
