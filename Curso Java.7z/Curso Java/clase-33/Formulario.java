import javax.swing.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ActionListener{
  private JTextField text_field1,text_field2;
  private JButton boton_sumar;
  private JLabel label1, label2,label3;

  public Formulario(){
    setLayout(null);
    label1 = new JLabel("Valor 1:");
    label1.setBounds(50,5,100,30);
    add(label1);

    label2 = new JLabel("Valor 2:");
    label2.setBounds(50,35,100,30);
    add(label2);

    label3 = new JLabel("Resultado:");
    label3.setBounds(120,80,100,30);
    add(label3);

    text_field1 = new JTextField();
    text_field1.setBounds(120,5,100,30);
    add(text_field1);

    text_field2 = new JTextField();
    text_field2.setBounds(120,35,100,30);
    add(text_field2);

    boton_sumar = new JButton("Sumar");
    boton_sumar.setBounds(50,80,100,30);
    add(boton_sumar);
    boton_sumar.addActionListener(this);
  }
  public void actionPerformed(ActionEvent e){
    if(e.getSource() == boton_sumar){
      int num_1 = 0, num_2 = 0, resultado = 0;
      num_1 = Integer.parseInt(text_field1.getText());
      num_2 = Integer.parseInt(text_field2.getText());
      resultado = num_1 + num_2;

      label3.setText("Resultado: " + resultado);
    }
  }

  public static void main(String args[]){
    Formulario form = new Formulario();
    form.setBounds(0,0,300,250);
    form.setVisible(true);
    form.setResizable(false);
    form.setLocationRelativeTo(null);
  }

}