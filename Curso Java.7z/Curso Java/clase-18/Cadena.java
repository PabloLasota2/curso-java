import java.util.Scanner;

public class Cadena{
  public static void main(String args[]){
   
   Scanner entrada = new Scanner(System.in);
   String cadena = "", cadenaExtraida = "";
   int cantidadCaracteres = 0, desde = 0, hasta = 0;
   
   System.out.print("Ingrese una palabra: ");
   cadena = entrada.nextLine();
   
   cantidadCaracteres = cadena.length();

   System.out.print("\nLa palabra "+cadena+" contiene "+cantidadCaracteres);

   System.out.print("\nDonde quiere comenzar la extraccion?: ");
   desde = entrada.nextInt();
   System.out.print("\nDonde quiere finalizar la extraccion?: ");
   hasta = entrada.nextInt();   

   cadenaExtraida = cadena.substring(desde,hasta);

   System.out.print("La parte de la cadena que se extrajo es: "+cadenaExtraida);

 }
}