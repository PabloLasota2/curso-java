import javax.swing.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ActionListener{
  private JButton boton1,boton2,boton3,botonSalir;
  private JLabel label1;
  public Formulario(){
   setLayout(null);
   boton1 = new JButton("UNO");
   boton1.setBounds(10,100,90,30);
   add(boton1);
   boton1.addActionListener(this);
   
   boton2 = new JButton("DOS");
   boton2.setBounds(110,100,90,30);
   add(boton2);
   boton2.addActionListener(this);

   boton3 = new JButton("TRES");
   boton3.setBounds(210,100,90,30);
   add(boton3);
   boton3.addActionListener(this);
   
   botonSalir = new JButton("Salir");
   botonSalir.setBounds(310,100,90,30);
   add(botonSalir);
   botonSalir.addActionListener(this);

   label1 = new JLabel("Esperando...");
   label1.setBounds(10,10,300,30);
   add(label1);
 }
  public void actionPerformed(ActionEvent e){
   if(e.getSource() == boton1){
    label1.setText("El numero precionado es 1");
   }
   if(e.getSource() == boton2){
    label1.setText("El numero precionado es 2");
   }
   if(e.getSource() == boton3){
    label1.setText("El numero precionado es 3");
   }
   if(e.getSource() == botonSalir){
    System.exit(0);
   }
  }
  public static void main(String args[]){
   Formulario form = new Formulario();
   form.setBounds(0,0,450,200);
   form.setVisible(true);
   form.setResizable(false);
   form.setLocationRelativeTo(null);
  }
 }