import java.util.Scanner;

public class Operaciones{
 public static void main(String args[]){
  Scanner entrada = new Scanner(System.in);
  int num_uno = 10, num_dos = 5, resultado = 0;
  
  System.out.println("Ingrese que desea hacer con los numeros?\n1-Sumar\n2-Restar\n3-Multiplicar\n4-Dividir\n\nOpcion:");

  switch(entrada.nextInt()){
   case 1:
    resultado = num_uno + num_dos;
    System.out.println("El resultado de la suma es:"+resultado);
    break;
   case 2:
    resultado = num_uno - num_dos;
    System.out.println("El resultado de la resta es:"+resultado);
    break;
   case 3:
    resultado = num_uno * num_dos;
    System.out.println("El resultado de la multiplicacion es:"+resultado);
    break;
   case 4:
    resultado = num_uno / num_dos;
    System.out.println("El resultado de la division es:"+resultado);
    break;
   default:
    System.out.println(opcion+" no es una opcion valida");
  }
 }
}