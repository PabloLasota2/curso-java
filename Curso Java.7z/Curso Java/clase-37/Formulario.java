import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ActionListener{
  private JMenuBar menubar;
  private JMenu menu,itemTamanio,itemColor;
  private JMenuItem itemTChico, itemTGrande, itemCRojo, itemCVerde;

  public Formulario(){
    setLayout(null);
    menubar = new JMenuBar();
    setJMenuBar(menubar);
    
    menu = new JMenu("Opciones");
    menubar.add(menu);
    
    itemTamanio = new JMenu("Tamaño de Ventana");
    menu.add(itemTamanio);

    itemColor = new JMenu("Color de fondo");
    menu.add(itemColor);

    itemTChico = new JMenuItem("300 x 200");
    itemTChico.addActionListener(this);
    itemTamanio.add(itemTChico);

    itemTGrande = new JMenuItem("640 x 480");
    itemTGrande.addActionListener(this);
    itemTamanio.add(itemTGrande);

    itemCRojo = new JMenuItem("Rojo");
    itemCRojo.addActionListener(this);
    itemColor.add(itemCRojo);

    itemCVerde = new JMenuItem("Verde");
    itemCVerde.addActionListener(this);
    itemColor.add(itemCVerde);

  }
  public void actionPerformed(ActionEvent e){
    Container fondo = this.getContentPane();
    if(e.getSource() == itemCRojo){
      fondo.setBackground(new Color(255,0,0));
    }
    if(e.getSource() == itemCVerde){
      fondo.setBackground(new Color(0,255,0));
    }
    if(e.getSource() == itemTChico){
      setSize(300,200);
    }
    if(e.getSource() == itemTGrande){
      setSize(640,480);
    }
  }
  public static void main(String args[]){
    Formulario form = new Formulario();
    form.setBounds(0,0,500,600);
    form.setVisible(true);
    form.setResizable(false);
    form.setLocationRelativeTo(null);
  }
}