import javax.swing.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ActionListener{
  private JTextField texto1;
  private JButton botonAceptar,botonSalir;
  private JLabel label1,label2;
  public Formulario(){
    setLayout(null);
    
    label1 = new JLabel("Usuario:");
    label1.setBounds(10,10,100,20);
    add(label1);

    label2 = new JLabel();
    label2.setBounds(10,30,100,20);
    add(label2);

    texto1 = new JTextField();
    texto1.setBounds(110,10,150,20);
    add(texto1);
    
    botonAceptar = new JButton("Aceptar");
    botonAceptar.setBounds(10,70,70,20);
    add(botonAceptar);
    botonAceptar.addActionListener(this);

    botonSalir = new JButton("Salir");
    botonSalir.setBounds(90,70,70,20);
    add(botonSalir);
    botonSalir.addActionListener(this);    
  }
  public void actionPerformed(ActionEvent e){
    if(e.getSource() == botonAceptar){
      String texto = texto1.getText();
      setTitle(texto);
      label2.setText(texto);
    }
    if(e.getSource() == botonSalir){
      System.exit(0);
    }
  }

  public static void main(String args[]){
    Formulario form = new Formulario();
    
    form.setBounds(0,0,200,300);
    form.setVisible(true);
    form.setResizable(false);
    form.setLocationRelativeTo(null);
  }
}