import java.util.Scanner;

public class Vectores{
  public static void main(String args[]){

  Scanner entrada = new Scanner(System.in);
  int longitud = 0;

  System.out.print("Ingrese la longitud del vector: ");
  longitud = entrada.nextInt();

  int numeros[] = new int[longitud];

  for(int i = 0; i < numeros.length; i++){
    for(int j = 0; j < 50; j++){
      System.out.println();
    }
    System.out.println("Ingrese un valor: ");
    numeros[i] = entrada.nextInt();
  }

  for(int j = 0; j < 50; j++){
    System.out.println();
  }

  for(int i = 0; i < numeros.length; i++){
    System.out.print("["+numeros[i]+"]");
  }
 }
}