import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ActionListener{
  private JMenuBar menubar;
  private JMenu menu;
  private JMenuItem item_1, item_2, item_3;

  public Formulario(){
    setLayout(null);
    menubar = new JMenuBar();
    setJMenuBar(menubar);
    
    menu = new JMenu("Opciones");
    menubar.add(menu);
    
    item_1 = new JMenuItem("Rojo");
    item_1.addActionListener(this);
    menu.add(item_1);

    item_2 = new JMenuItem("Verde");
    item_2.addActionListener(this);
    menu.add(item_2);

    item_3 = new JMenuItem("Azul");
    item_3.addActionListener(this);
    menu.add(item_3);
  }
  public void actionPerformed(ActionEvent e){
    Container fondo = this.getContentPane();

    if(e.getSource() == item_1){
      fondo.setBackground(new Color(255,0,0));
    }
    if(e.getSource() == item_2){
      fondo.setBackground(new Color(0,255,0));
    }
    if(e.getSource() == item_3){
      fondo.setBackground(new Color(0,0,255));
    }
  }
  public static void main(String args[]){
    Formulario form = new Formulario();
    form.setBounds(0,0,500,600);
    form.setVisible(true);
    form.setResizable(false);
    form.setLocationRelativeTo(null);
  }
}