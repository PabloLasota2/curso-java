import javax.swing.*;

public class Formulario extends JFrame{
  private JTextArea zona_de_texto;
  private Formulario(){
  setLayout(null);

  zona_de_texto = new JTextArea();
  zona_de_texto.setBounds(10,10,250,500);
  add(zona_de_texto);
    
  }

  public static void main(String args[]){
    Formulario form = new Formulario();
    form.setVisible(true);
    form.setResizable(false);
    form.setBounds(0,0,270,520);
    form.setLocationRelativeTo(null);
  }
}